public class Pair {
	Node first;
	double second;
	
	public Pair(Node f, double s) {
		first = f;
		second = s;
	}
	
}