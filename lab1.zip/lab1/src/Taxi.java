// Taxi class
public class Taxi extends Point {
	public int id;
}
