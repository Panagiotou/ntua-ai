public class Client extends Point {
	private int id;

        public void setid(int nid){
            id = nid;
        }
}
